﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharpConsol
{
    class MainClass
    {
        private static void insertPerson(DBConnect person, int maxAgeId)
        {
            string baseStatement = String.Format("INSERT INTO `{0}`.person (id, name, ageId) VALUES", person.DATABASE);

            List<string> values = new List<string>();
            Random r = new Random();

            foreach (string name in new string[] { "Adam", "Bob", "Calvin" })
            {
                string x = String.Format("(default, '{0}', {1})", name, r.Next(1, maxAgeId));
                values.Add(x);
            }
            person.Insert(String.Format("{0}{1};", baseStatement, String.Join(",", values.ToArray())));
        }
        private static void insert(DBConnect person)
        {
            insertPerson(person, 10);
        }

        public static void Main(string[] args)
        {
            const string database = "odbc-trigger";

            DBConnect person = new DBConnect(database);
            person.CreateConnect(true);
            person.Truncate();
            insert(person);
            person.Update("UPDATE person SET name='Cain' WHERE id=1;");
            person.Delete("DELETE FROM person WHERE id=2;");
        }
    }
}
